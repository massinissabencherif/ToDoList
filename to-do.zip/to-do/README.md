# nodejs-todo

<h2> Une To do list basique sans stylisation en Node.js et Express</h2>

<p> Cette to-do permets de stocker des tâches dans des array différents </p>

<br>

<p> Pour tester l'application :</p>

<ol>
<li> lancer un npm install dans le terminal pour installer tout les éléments, ensuite lancer node index.js pour lancer l'app. </li>

<li> Se connecter sur http://localhost:3000/ pour l'utiliser en live. </li>
</ol>

<p> Cette application a été créer avec l'aide de tutos youtubes, et de mon grand ami @MAXIME ILIKOUD, ingénieur éléctronique à Thalès</a>

